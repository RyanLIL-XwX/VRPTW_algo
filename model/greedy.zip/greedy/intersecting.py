from shapely.geometry import LineString
from typing import List
import random
import math


def get_path_line(vehicle) -> LineString:
    coords = [(order.receiving_latitude, order.receiving_longitude) for order in vehicle.path]
    if len(coords) < 2:
        return None
    return LineString(coords)


def distance(order1, order2):
    return math.sqrt((order1.receiving_latitude - order2.receiving_latitude) ** 2 +
                     (order1.receiving_longitude - order2.receiving_longitude) ** 2)


def calculate_total_distance(route):
    if len(route) < 2:
        return 0.0
    total_distance = 0.0
    for i in range(len(route) - 1):
        total_distance += distance(route[i], route[i + 1])
    return total_distance


def crossover(parent1, parent2):
    size = len(parent1)
    start, end = sorted(random.sample(range(size), 2))
    child = [None] * size
    child[start:end] = parent1[start:end]

    for item in parent2:
        if item not in child:
            for i in range(size):
                if child[i] is None:
                    child[i] = item
                    break
    return child


def mutate(route, mutation_rate=0.01):
    for i in range(len(route)):
        if random.random() < mutation_rate:
            j = random.randint(0, len(route) - 1)
            route[i], route[j] = route[j], route[i]
    return route


def select(population, fitnesses, k=3):
    selected = random.choices(population, weights=fitnesses, k=k)
    return min(selected, key=lambda route: calculate_total_distance(route))


def genetic_algorithm(route, population_size=100, generations=500, mutation_rate=0.01):
    if len(route) < 2:
        return route
    population = [random.sample(route, len(route)) for _ in range(population_size)]
    for _ in range(generations):
        fitnesses = [1 / calculate_total_distance(ind) if calculate_total_distance(ind) > 0 else float('inf') for ind in
                     population]
        new_population = []
        for _ in range(population_size):
            parent1 = select(population, fitnesses)
            parent2 = select(population, fitnesses)
            child = crossover(parent1, parent2)
            child = mutate(child, mutation_rate)
            new_population.append(child)
        population = new_population
    return min(population, key=lambda route: calculate_total_distance(route))


def optimize_vehicle_route(vehicle):
    vehicle.path = genetic_algorithm(vehicle.path)
    return vehicle


def optimize_vehicle_routes(vehicles: List) -> List:
    optimized_vehicles = []
    for vehicle in vehicles:
        optimized_vehicles.append(optimize_vehicle_route(vehicle))
    return optimized_vehicles
